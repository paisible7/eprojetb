const container0 = document.querySelector('.cont0');
const container1 = document.querySelector('.cont1');
const container2 = document.querySelector('.cont2');
const btn1 = document.querySelector('.btn1');
const btn2 = document.querySelector('.btn2');
const btn3 = document.querySelector('.btn3');
const wrap = document.querySelector('.wrapper');
const banks = document.querySelector('.bankme');
const mobiles = document.querySelector('.mobime');
const drap = document.querySelector('.drapper');
const equme = document.getElementById('equity');
const ubame = document.getElementById('uba');
const ecome = document.getElementById('ecobank');
const rawme = document.getElementById('rawbank');


btn1.addEventListener('click', () => {
    container0.classList.add('mover');
});

mobiles.addEventListener('click', () => {
    document.querySelector('.form1').style.display = "none"
    document.querySelector('.form2').style.display = "block"
});

banks.addEventListener('click', () => {
    document.querySelector('.form2').style.display = "none"
    document.querySelector('.form1').style.display = "block"
});

btn2.addEventListener('click', () => {
    container2.classList.add('deplacer')
});

equme.addEventListener('click', () => {
    compte = "EQUITY BANK"
    document.getElementById('ok').innerHTML = compte

});

ubame.addEventListener('click', () => {
    compte = "UBA"
    document.getElementById('ok').innerHTML = compte

});

ecome.addEventListener('click', () => {
    compte = "ECOBANK"
    document.getElementById('ok').innerHTML = compte

});

rawme.addEventListener('click', () => {
    compte = "RAWBANK"
    document.getElementById('ok').innerHTML = compte

});


function cutmatr() {
    var matricule = document.getElementById("email").value;
    document.getElementById('ok').innerHTML = matricule.slice(0, 7).toUpperCase();
};

function message() {
    var container = document.getElementById('container');
    var currentDate = new Date()
    var div = document.createElement('div');
    div.className = "grille";
    div.innerHTML = currentDate;
    container.appendChild(div);
};

function detNumBin() {
    var numeroCarte = document.getElementById("numcarte").value;
    var visaPattern = /^4[0-9]{5}/;
    var mastercardPattern = /^(5[1-5]|2[2-7])[0-9]{4}/;
    var amexPattern = /^3[47][0-9]{4}/;
    var discoverPattern = /^(6011|65|64[4-9])[0-9]{2}/;
    if (visaPattern.test(numeroCarte)) {
        const img = document.getElementById("imgRandom");
        img.setAttribute("src", "image/visa.png");
    }
    else if (mastercardPattern.test(numeroCarte)) {
        const img = document.getElementById("imgRandom");
        img.setAttribute("src", "image/mastacard.png")
    }
    else if (amexPattern.test(numeroCarte)) {
        const img = document.getElementById("imgRandom");
        img.setAttribute("src", "image/amexexpress.png")
    }
    else if (discoverPattern.test(numeroCarte)) {
        const img = document.getElementById("imgRandom");
        img.setAttribute("src", "image/disc.png")
    }
    else { }
};


const modal = document.querySelector(".modal");
const overlay = document.querySelector(".overlay");
const openModalBtn = document.querySelector(".btn-open");
const closeModalBtn = document.querySelector(".btn-close");

const closeModal = function () {
    modal.classList.add("hidden");
    overlay.classList.add("hidden");
};

closeModalBtn.addEventListener("click", closeModal);
overlay.addEventListener("click", closeModal);

const openModal = function () {
    modal.classList.remove("hidden");
    overlay.classList.remove("hidden");
};

openModalBtn.addEventListener("click", openModal);

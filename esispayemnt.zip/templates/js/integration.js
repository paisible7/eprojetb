const mongoose = require('mongoose')
const paiementsSchema = mongoose.Schema({
    transaction_id : {
        type : String,
        required : true
    },
    amount : {
        type : Number,
        required : true
    },
    currency : {
        type : String,
        required : true
    },
    customer_number : {
        type : String,
        required : true
    },
    mobile_money_provider : {
        type : String,
        required : true
    },
    mobile_money_phone_number :{
        type : String,
        required: true
    }
}, {
    timestamps: true
})

module.exports = mongoose.model('Paiement', paiementsSchema)